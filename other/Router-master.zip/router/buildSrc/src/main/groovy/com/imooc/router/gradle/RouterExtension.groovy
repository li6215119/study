package com.imooc.router.gradle

class RouterExtension {
    String wikiDir
}