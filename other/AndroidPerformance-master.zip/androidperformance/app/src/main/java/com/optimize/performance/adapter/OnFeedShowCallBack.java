package com.optimize.performance.adapter;

public interface OnFeedShowCallBack {
    void onFeedShow();
}
