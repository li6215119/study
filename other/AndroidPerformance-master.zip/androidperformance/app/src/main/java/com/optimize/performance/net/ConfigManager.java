package com.optimize.performance.net;

public class ConfigManager {

    public static boolean sOpenClick = true;

}
