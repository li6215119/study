package com.optimize.performance.launchstarter.task;

public interface TaskCallBack {

    void call();
}
