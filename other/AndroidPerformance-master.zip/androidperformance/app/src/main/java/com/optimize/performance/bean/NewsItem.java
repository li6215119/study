package com.optimize.performance.bean;

public class NewsItem {

    public String newsId;
    public String title;
    public String abstractX;
    public String url;
    public String imgurl;
    public String imgurl1;
    public String imgurl2;
    public String pub_time;
    public String publishTime;
    public String currentTime;
    public String pub_time_new;
    public String pub_time_detail;
    public String atype;
    public String atypeName;
    public String newsAppId;
    public String source;
    public String duration;
    public String hasCopyRight;
    public String vid;
    public String commentsNum;
    public String commentId;
    public String targetId;
    public String isDisabled;
    public String tag_key;
    public String cmsColumn;
    public String cmsSite;
    public String shareUrl;
    public String commentNum;
    public String upNum;
    public String footer;
    public String isCollect;
    public String videoUrl;
}
