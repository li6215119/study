package com.optimize.performance.aop;

public class ActivityRecord {

    public long mOnCreateTime;
    public long mOnWindowsFocusChangedTime;

}
