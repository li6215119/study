package com.optimize.performance.memory;

public interface CallBack {
    void dpOperate();
}
