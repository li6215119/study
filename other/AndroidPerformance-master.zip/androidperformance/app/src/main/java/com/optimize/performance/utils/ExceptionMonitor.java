package com.optimize.performance.utils;

public class ExceptionMonitor {

    public static void monitor(String message){
        // 数据缓存及后续上报逻辑
    }

}
