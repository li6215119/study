package com.imooc.lib_image_loader.image;

import com.bumptech.glide.request.RequestListener;

public interface CustomRequestListener extends RequestListener {

}
