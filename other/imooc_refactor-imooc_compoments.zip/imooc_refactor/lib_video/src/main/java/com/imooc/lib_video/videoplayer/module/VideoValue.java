package com.imooc.lib_video.videoplayer.module;

/**
 * Video实体
 */
public class VideoValue {

    public String resourceID;
    public String adid;
    public String resource;
    public String thumb;
    public String clickUrl;
    public String type;
}
