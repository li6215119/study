# imooc_music_app

 组件化架构实现慕课云音乐app