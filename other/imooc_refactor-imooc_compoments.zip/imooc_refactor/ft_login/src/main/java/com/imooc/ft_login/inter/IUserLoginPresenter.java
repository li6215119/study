package com.imooc.ft_login.inter;

/**
 * Presenter层对外提供的方法
 */
public interface IUserLoginPresenter {

    void login(String username, String password);
}
