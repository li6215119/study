package com.imooc.ft_login.api;

public class MockData {


    public static final String LOGIN_DATA = "{\n"
            + "  \"ecode\": 0,\n"
            + "  \"emsg\": \"\",\n"
            + "  \"data\": {\n"
            + "    \"userId\": \"0001\",\n"
            + "    \"photoUrl\": \"http://img1.imgtn.bdimg.com/it/u=2848169099,1045524542&fm=26&gp=0.jpg\",\n"
            + "    \"name\": \"任志强\",\n"
            + "    \"tick\": \"任志强\",\n"
            + "    \"mobile\": \"18734924592\",\n"
            + "    \"platform\": \"youku\"\n"
            + "  }\n"
            + "}";
}
