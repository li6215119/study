package com.imooc.ft_home.model.discory;

import com.imooc.lib_base.BaseModel;

/**
 * @文件描述：推荐实体
 */
public class RecommandBodyValue extends BaseModel {

  public int type;
  public String avatr;
  public String title;
  public String text;
  public String zan;
  public String msg;
  public String play;
  public String time;
  public String logo;
}
