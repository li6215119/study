package com.imooc.ft_home.model.friend;

import com.imooc.lib_base.BaseModel;

/**
 * Created by renzhiqiang
 */
public class BaseFriendModel extends BaseModel {

  public String ecode;
  public String emsg;
  public FriendModel data;
}
