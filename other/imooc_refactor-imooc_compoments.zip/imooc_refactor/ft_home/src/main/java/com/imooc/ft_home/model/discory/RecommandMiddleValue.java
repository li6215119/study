package com.imooc.ft_home.model.discory;

import com.imooc.lib_base.BaseModel;

public class RecommandMiddleValue extends BaseModel {

  public String info;
  public String imageUrl;
}
