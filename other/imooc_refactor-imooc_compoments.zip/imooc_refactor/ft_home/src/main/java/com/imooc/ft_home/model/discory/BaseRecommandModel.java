package com.imooc.ft_home.model.discory;

import com.imooc.lib_base.BaseModel;

/**
 * Created by renzhiqiang
 */
public class BaseRecommandModel extends BaseModel {

  public String ecode;
  public String emsg;
  public RecommandModel data;
}
