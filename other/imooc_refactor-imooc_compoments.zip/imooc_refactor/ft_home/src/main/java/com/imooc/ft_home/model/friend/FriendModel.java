package com.imooc.ft_home.model.friend;

import com.imooc.lib_base.BaseModel;
import java.util.ArrayList;

/**
 * @文件描述：朋友实体
 */
public class FriendModel extends BaseModel {
  public ArrayList<FriendBodyValue> list;
}
