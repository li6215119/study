package com.imooc.lib_base.ft_login.model;

public class LoginEvent {

}
