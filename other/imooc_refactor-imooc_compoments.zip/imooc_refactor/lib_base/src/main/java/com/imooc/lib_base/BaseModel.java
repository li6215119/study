package com.imooc.lib_base;

import java.io.Serializable;

/**
 * @description 实体基类
 */
public class BaseModel implements Serializable {

  private static final long serialVersionUID = 1L;
}
