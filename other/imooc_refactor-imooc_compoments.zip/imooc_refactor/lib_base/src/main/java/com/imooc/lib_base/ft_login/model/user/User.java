package com.imooc.lib_base.ft_login.model.user;

import com.imooc.lib_base.BaseModel;

/**
 * 用户数据协议
 */
public class User extends BaseModel {
  public int ecode;
  public String emsg;
  public UserContent data;
}
