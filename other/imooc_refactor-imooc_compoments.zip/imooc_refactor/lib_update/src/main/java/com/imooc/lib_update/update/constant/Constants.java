package com.imooc.lib_update.update.constant;

public class Constants {

  private static final String ROOT_URL = "http://imooc.com/api";
  /**
   * 检查更新接口
   */
  public static String CHECK_UPDATE = ROOT_URL + "/config/check_update.php";
}
