package com.imooc.lib_update.app;

public class MockData {

  public static final String UPDATE_DATA = "{\n"
      + "  \"ecode\": 0,\n"
      + "  \"emsg\": \"\",\n"
      + "  \"data\": {\n"
      + "    \"currentVersion\": 2\n"
      + "  }\n"
      + "}";
}
