package com.imooc.lib_update.update.model;

import java.io.Serializable;

/**
 * Created by renzhiqiang on 16/8/23.
 */
public class UpdateInfo implements Serializable {

  private static final long serialVersionUID = -5392994583182441762L;

  public int currentVersion;
}
