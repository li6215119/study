package inuker.com.testpipefd;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.Looper;
import android.os.MessageQueue;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;
import android.util.Log;

import java.io.FileDescriptor;

public class MyService extends Service implements MessageQueue.OnFileDescriptorEventListener {

    private ParcelFileDescriptor mPfd;
    private ICallback mCallback;

    private void observe(ParcelFileDescriptor pfd, ICallback callback) {
        mPfd = pfd;

        FileDescriptor fd = pfd.getFileDescriptor();
        IoUtils.setBlocking(fd, false);

        mCallback = callback;
        MessageQueue queue = Looper.getMainLooper().getQueue();
        queue.addOnFileDescriptorEventListener(fd, EVENT_INPUT, this);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return new IMyAidlInterface.Stub() {
            @Override
            public void publish(ParcelFileDescriptor pfd, ICallback callback) throws RemoteException {
                observe(pfd, callback);
            }
        };
    }

    @Override
    public int onFileDescriptorEvents(FileDescriptor fd, int events) {
        Log.v("bush", String.format("onEvents: event = %d at %s", events, Thread.currentThread().getName()));

        if ((events & EVENT_ERROR) != 0) {
            return 0;
        }

        final ParcelFileDescriptor.AutoCloseInputStream reader = new ParcelFileDescriptor.AutoCloseInputStream(mPfd);

        StringBuilder sb = new StringBuilder();

        try {
            final byte[] buffer = new byte[4];
            int size;

            do {
                Log.v("bush", "read start");
                size = reader.read(buffer, 0, buffer.length);
                Log.v("bush", "read end: " + size);
                if (size > 0) {
                    sb.append(new String(buffer, 0, size));
                }
            } while (size > 0);
        } catch (Exception e) {
            e.printStackTrace();
            Log.v("bush", "exception occured");
        }

        try {
            mCallback.onRecv(sb.toString());
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return EVENT_INPUT;
    }
}
