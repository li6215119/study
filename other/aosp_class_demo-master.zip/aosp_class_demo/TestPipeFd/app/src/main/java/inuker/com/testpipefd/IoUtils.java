package inuker.com.testpipefd;

import java.io.FileDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class IoUtils {

    public static void setBlocking(FileDescriptor fd, boolean blocking) {
        try {
            Class clazz = Class.forName("libcore.io.IoUtils");
            Method method = clazz.getMethod("setBlocking", FileDescriptor.class, boolean.class);
            method.setAccessible(true);
            method.invoke(null, fd, blocking);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }
}
