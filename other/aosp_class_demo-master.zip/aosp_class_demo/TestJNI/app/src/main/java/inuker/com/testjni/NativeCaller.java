package inuker.com.testjni;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.lang.ref.WeakReference;

public class NativeCaller {

    private static final String TAG = "bush";

    static {
        System.loadLibrary("mytest");
    }

    private long mPtr;

    public NativeCaller() {
        mPtr = nativeInit(new WeakReference<>(this));
    }

    @Override
    protected void finalize() throws Throwable {
        try {
            dispose();
        } finally {
            super.finalize();
        }
    }

    public void dispose() {
        if (mPtr != 0) {
            nativeDispose(mPtr);
            mPtr = 0;
        }
    }

    public void call() {
        if (mPtr != 0) {
            nativeCall(mPtr);
        }
    }

    private static native long nativeInit(WeakReference<NativeCaller> ref);
    private static native void nativeCall(long ptr);
    private static native void nativeDispose(long ptr);

    public void onCallback(int val) {
        Log.v(TAG, String.format("onCallback at thread %s, val = %d", Thread.currentThread().getName(), val));
    }

    private void dispatchCallback(final int val) {
        Log.v(TAG, String.format("dispatchCallback at thread %s", Thread.currentThread().getName()));

        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                onCallback(val);
            }
        });
    }
}
