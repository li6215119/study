#include "utils.h"
#include <pthread.h>
#include <unistd.h>

struct {
	JavaVM *javaVM;
	jclass clazz;
	jmethodID dispatchCallback;

	jclass reference;
	jmethodID refGet;
} gs;


struct MyInfo {
	jobject ref;
};

static void *callback(void *data) {
	MyInfo *info = static_cast<MyInfo *>(data);

	JNIEnv *env;
	gs.javaVM->AttachCurrentThread(&env, NULL);

	jobject o = env->CallObjectMethod(info->ref, gs.refGet);
	if (o != NULL) {
		env->CallVoidMethod(o, gs.dispatchCallback, 1);
	} else {
		LOGE("object has been gc, weak ref null");
	}

	gs.javaVM->DetachCurrentThread();
	return NULL;
}

static jlong
nativeInit(JNIEnv *env, jclass clazz, jobject weakRef) {

	MyInfo *myinfo = new MyInfo();
	myinfo->ref = env->NewGlobalRef(weakRef);

	return reinterpret_cast<jlong>(myinfo);
}

static void
nativeCall(JNIEnv *env, jclass clazz, jlong ptr) {
	MyInfo *myinfo = reinterpret_cast<MyInfo *>(ptr);

	pthread_t thread;
	pthread_create(&thread, NULL, callback, myinfo);
}

static void
nativeDispose(JNIEnv *env, jclass clazz, jlong ptr) {
	MyInfo *myinfo = reinterpret_cast<MyInfo *>(ptr);
	env->DeleteGlobalRef(myinfo->ref);
	delete myinfo;
}

static JNINativeMethod methods[] = {
		{"nativeInit", "(Ljava/lang/ref/WeakReference;)J", (void *) nativeInit},
		{"nativeCall", "(J)V",                             (void *) nativeCall},
		{"nativeDispose", "(J)V",                             (void *) nativeDispose},
};

static int registerNativeMethods(JNIEnv *env, JNINativeMethod *gMethods,
                                 int numMethods) {
	gs.clazz = static_cast<jclass>(env->NewGlobalRef(
			env->FindClass("inuker/com/testjni/NativeCaller")));
	gs.reference = static_cast<jclass>(env->NewGlobalRef(
			env->FindClass("java/lang/ref/Reference")));
	gs.dispatchCallback = env->GetMethodID(gs.clazz, "dispatchCallback", "(I)V");
	gs.refGet = env->GetMethodID(gs.reference, "get", "()Ljava/lang/Object;");

	if (env->RegisterNatives(gs.clazz, gMethods, numMethods) < 0) {
		return JNI_FALSE;
	}

	return JNI_TRUE;
}

static int registerNatives(JNIEnv *env) {
	if (!registerNativeMethods(env, methods, sizeof(methods) / sizeof(methods[0]))) {
		return JNI_FALSE;
	}

	return JNI_TRUE;
}


jint JNI_OnLoad(JavaVM *vm, void *reserved) {
	JNIEnv *env = NULL;

	gs.javaVM = vm;

	if (vm->GetEnv((void **) &env, JNI_VERSION_1_4) != JNI_OK) {
		return JNI_ERR;
	}

	if (registerNatives(env) == JNI_FALSE) {
		return JNI_ERR;
	}

	return JNI_VERSION_1_4;
}