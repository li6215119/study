public class ZygoteInit {

    public static void main(String[] args) {




    }
}
