package inuker.com.testbitmap;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    private IMyAidlInterface mCaller;

    private ImageView mImageView;
    private Bitmap mBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bindToService();

        mBitmap = Utils.getBitmapFromAssets(this, "test.jpg");

        mImageView = findViewById(R.id.image);
        findViewById(R.id.btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Utils.start(TAG);
                publishBitmap();
                Utils.end(TAG);
            }
        });
    }

    private final ICallback.Stub mCallback = new ICallback.Stub() {
        @Override
        public void onCallback(final Bitmap bitmap) throws RemoteException {
            Log.v("bush", String.format("bitmap size = %d/%d", bitmap.getWidth(), bitmap.getHeight()));
//            showBitmap(bitmap);
        }
    };

    private void showBitmap(final Bitmap b) {
        final Bitmap o = Bitmap.createScaledBitmap(b, b.getWidth() / 4, b.getHeight() / 4, false);
        mImageView.post(new Runnable() {
            @Override
            public void run() {
                mImageView.setImageBitmap(o);
            }
        });
    }

    private void publishBitmap() {
        if (mBitmap != null) {
            try {
                mCaller.publishBitmap(mBitmap, mCallback);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }

    private void bindToService() {
        Intent intent = new Intent(this, MyService.class);
        bindService(intent, mConnection, BIND_AUTO_CREATE);
    }

    private final ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            IMyAidlInterface caller = IMyAidlInterface.Stub.asInterface(service);
            mCaller = caller;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

        }
    };
}
