package inuker.com.testbitmap;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.util.Log;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

public class Utils {

    private static HashMap<String, Long> mTimes = new HashMap<>();

    public static void close(Closeable c) {
        if (c != null) {
            try {
                c.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static Bitmap getBitmapFromAssets(Context c, String fileName) {
        InputStream in = null;
        Bitmap bm = null;
        try {
            in = c.getAssets().open(fileName);
            bm = BitmapFactory.decodeStream(in);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            Utils.close(in);
        }
        return bm;
    }

    public static synchronized void start(String tag) {
        mTimes.put(tag, System.currentTimeMillis());
    }

    public static synchronized void end(String tag) {
        Log.v("bush", String.format("%s takes %dms", tag, System.currentTimeMillis() - mTimes.remove(tag)));
    }
}
