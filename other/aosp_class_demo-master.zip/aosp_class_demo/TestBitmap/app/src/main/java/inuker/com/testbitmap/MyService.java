package inuker.com.testbitmap;

import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;

public class MyService extends Service {

    private static final String TAG = MyService.class.getSimpleName();

    @Override
    public IBinder onBind(Intent intent) {
        return new IMyAidlInterface.Stub() {
            @Override
            public void publishBitmap(Bitmap bitmap, ICallback callback) throws RemoteException {
                Log.v("bush", String.format("Receive bitmap %s", bitmap));

                Utils.start(TAG);
                callback.onCallback(bitmap);
                Utils.end(TAG);
            }

        };
    }
}
