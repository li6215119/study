package inuker.com.testbarrier;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.MessageQueue;
import android.view.View;
import android.widget.Toast;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Deque;
import java.util.LinkedList;

public class MainActivity extends Activity {

    private HandlerThread mThread;
    private Handler mHandler;

    private Deque<Integer> mBarrierTokens = new LinkedList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mThread = new HandlerThread("");
        mThread.start();

        mHandler = new Handler(mThread.getLooper());

        findViewById(R.id.addBarrier).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                addBarrier();
            }
        });

        findViewById(R.id.removeBarrier).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                removeBarrier();
            }
        });

        findViewById(R.id.normal).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                sendNormalMessage();
            }
        });

        findViewById(R.id.async).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                sendAsyncMessage();
            }
        });
    }

    private void addBarrier() {
        try {
            Method method = MessageQueue.class.getMethod("postSyncBarrier");
            method.setAccessible(true);
            int barrierToken = (int) method.invoke(mHandler.getLooper().getQueue());
            showToast(String.format("addBarrier success: %d", barrierToken));
            mBarrierTokens.add(barrierToken);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    private void removeBarrier() {
        if (mBarrierTokens.isEmpty()) {
            return;
        }
        try {
            Method method = MessageQueue.class.getMethod("removeSyncBarrier", int.class);
            method.setAccessible(true);
            int barrierToken = mBarrierTokens.pollLast();
            method.invoke(mHandler.getLooper().getQueue(), barrierToken);
            showToast(String.format("removeBarrier success: %d", barrierToken));
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    private void sendNormalMessage() {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                showToast("Normal Message");
            }
        });
    }

    private void sendAsyncMessage() {
        Message msg = Message.obtain(mHandler, new Runnable() {
            @Override
            public void run() {
                showToast("Async Message");
            }
        });
        msg.setAsynchronous(true);
        msg.sendToTarget();
    }

    private void showToast(final String s) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, s, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
