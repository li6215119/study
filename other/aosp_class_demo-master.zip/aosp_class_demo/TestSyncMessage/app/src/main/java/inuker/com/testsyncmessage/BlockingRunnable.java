package inuker.com.testsyncmessage;

import android.os.Handler;
import android.os.SystemClock;

import java.util.concurrent.Callable;

public final class BlockingRunnable<T> implements Runnable {
    private final Callable<T> mTask;
    private boolean mDone;

    private T mResult;

    public BlockingRunnable(Callable<T> task) {
        mTask = task;
    }

    @Override
    public void run() {
        try {
            mResult = mTask.call();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            synchronized (this) {
                mDone = true;
                notifyAll();
            }
        }
    }

    public T getResult() {
        return mResult;
    }

    public T postAndWait(Handler handler, long timeout) {
        if (!handler.post(this)) {
            return null;
        }

        synchronized (this) {
            if (timeout > 0) {
                final long expirationTime = SystemClock.uptimeMillis() + timeout;
                while (!mDone) {
                    long delay = expirationTime - SystemClock.uptimeMillis();
                    if (delay <= 0) {
                        return null; // timeout
                    }
                    try {
                        wait(delay);
                    } catch (InterruptedException ex) {
                    }
                }
            } else {
                while (!mDone) {
                    try {
                        wait();
                    } catch (InterruptedException ex) {
                    }
                }
            }
        }
        return mResult;
    }



}



