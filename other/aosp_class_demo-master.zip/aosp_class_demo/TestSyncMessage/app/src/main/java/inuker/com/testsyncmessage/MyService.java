package inuker.com.testsyncmessage;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;

import inuker.com.testsyncmessage.proxy.BaseProxyImpl;

public class MyService extends Service {

    private BaseProxyImpl<IMyAidlInterface> mBase = new BaseProxyImpl<IMyAidlInterface>() {
        @Override
        public IMyAidlInterface create() {
            return new RemoteServiceImpl();
        }
    };

    private IMyAidlInterface mServiceImpl = mBase.get();

    @Override
    public IBinder onBind(Intent intent) {
        return new IMyAidlInterface.Stub() {
            @Override
            public int setName(String name) throws RemoteException {
                return mServiceImpl.setName(name);
            }

            @Override
            public int setAge(int age) throws RemoteException {
                return mServiceImpl.setAge(age);
            }

            @Override
            public void setPwd(String pwd) throws RemoteException {
                mServiceImpl.setPwd(pwd);
            }
        };
    }
}
