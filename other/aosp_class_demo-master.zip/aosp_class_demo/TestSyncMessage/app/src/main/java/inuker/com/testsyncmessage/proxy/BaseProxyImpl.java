package inuker.com.testsyncmessage.proxy;

import android.os.Handler;
import android.os.HandlerThread;

import java.util.concurrent.atomic.AtomicInteger;

public abstract class BaseProxyImpl<T> {

    private static AtomicInteger hashCounter = new AtomicInteger(0);
    private final int hash = hashCounter.getAndAdd(0x61c88647 * 2);

    private volatile T mInstance;

    public final T get() {
        if (mInstance == null) {
            synchronized (BaseProxyImpl.class) {
                if (mInstance == null) {
                    T o = create();
                    mInstance = ProxyUtils.getProxy(o, o.getClass().getInterfaces(), getHandler());
                }
            }
        }
        return mInstance;
    }

    private Handler getHandler() {
        HandlerThread t = new HandlerThread(getName());
        t.start();

        return new Handler(t.getLooper());
    }

    private String getName() {
        return String.format("proxy_worker_%d", hash);
    }

    public abstract T create();
}