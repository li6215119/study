package inuker.com.testsyncmessage.proxy;

import android.os.Handler;

import java.lang.ref.WeakReference;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

public class ProxyInvocationHandler implements InvocationHandler {

    private Object mObject;

    private Handler mHandler;

    private boolean mAsync;

    public ProxyInvocationHandler(Object object, Handler handler, boolean async) {
        this.mHandler = handler;
        this.mObject = getObject(object);
        mAsync = async;
    }

    @Override
    public Object invoke(Object proxy, final Method method, final Object[] args) throws Throwable {
        if (mHandler == null) {
            return method.invoke(getObject(), args);
        } else {
            FutureTask<Object> task = new FutureTask<>(new Callable<Object>() {

                @Override
                public Object call() throws Exception {
                    Object o = getObject();
                    return o != null ? method.invoke(o, args) : null;
                }
            });
            mHandler.post(task);
            return mAsync ? null : task.get();
        }
    }

    private Object getObject(Object object) {
        return new WeakReference<Object>(object);
    }

    private Object getObject() {
        return ((WeakReference<Object>) mObject).get();
    }
}
