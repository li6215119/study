package inuker.com.testsyncmessage;

import android.os.IBinder;
import android.util.Log;

public class RemoteServiceImpl implements IMyAidlInterface {

    @Override
    public int setName(String name) {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return 13;
    }

    @Override
    public int setAge(int age) {
        return 29;
    }

    @Override
    public void setPwd(String pwd) {
        Log.v("bush", "setPwd start at " + Thread.currentThread().getName());
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public final IBinder asBinder() {
        throw new UnsupportedOperationException();
    }
}
