package inuker.com.testsyncmessage.proxy;

import android.os.Handler;
import android.os.Looper;

import java.lang.reflect.Proxy;

public class ProxyUtils {

    public static <T> T getProxy(Object object, Class<?>[] intfs, Handler handler, boolean async) {
        return (T) Proxy.newProxyInstance(object.getClass().getClassLoader(),
                intfs, new ProxyInvocationHandler(object, handler, async));
    }

    public static <T> T getProxy(Object object, Class<?>[] intfs, Handler handler) {
        return (T) getProxy(object, intfs, handler, false);
    }

    public static <T> T getProxy(Object object, Class<?>[] intfs) {
        return (T) getProxy(object, intfs, defaultHandler());
    }

    public static <T> T getProxy(Object object, Class<?> intf) {
        return (T) getProxy(object, new Class<?>[]{intf}, defaultHandler());
    }

    private static Handler defaultHandler() {
        Looper looper = Looper.myLooper();
        return new Handler(looper != null ? looper : Looper.getMainLooper());
    }
}
