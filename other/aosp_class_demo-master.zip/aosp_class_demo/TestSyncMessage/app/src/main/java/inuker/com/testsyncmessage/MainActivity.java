package inuker.com.testsyncmessage;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

public class MainActivity extends AppCompatActivity {

    private HandlerThread mThread;
    private Handler mHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mThread = new HandlerThread("worker");
        mThread.start();

        mHandler = new Handler(mThread.getLooper());

        findViewById(R.id.button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendSyncMessage();
            }
        });

        findViewById(R.id.button2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendSyncMessageForResult();
            }
        });

        findViewById(R.id.button3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendSyncMessageWithTask();
            }
        });

        findViewById(R.id.button4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, TestActivity.class);
                startActivity(intent);
            }
        });
    }

    private void sendSyncMessage() {
        sendSyncMessage(mHandler, new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }, 0);
        showToast(R.string.msg_over);
    }

    private void sendSyncMessage(Handler h, Runnable r, long timeout) {
        try {
            Method method = Handler.class.getMethod("runWithScissors", Runnable.class, long.class);
            method.setAccessible(true);
            method.invoke(h, r, timeout);
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    private void sendSyncMessageForResult() {
        String s = sendSyncMessageForResult(mHandler, new Callable<String>() {
            @Override
            public String call() throws Exception {
                Thread.sleep(3000);
                return "hello world!!";
            }
        }, 0);
        showToast(s);
    }

    private String sendSyncMessageForResult(Handler h, Callable<String> r, long timeout) {
        BlockingRunnable<String> br = new BlockingRunnable<>(r);
        return br.postAndWait(h, timeout);
    }

    private void sendSyncMessageWithTask() {
        String s = sendSyncMessageWithTask(mHandler, new FutureTask<String>(new Callable<String>() {
            @Override
            public String call() {
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                return "hello";
            }
        }));
        showToast(s);
    }

    private String sendSyncMessageWithTask(Handler h, FutureTask<String> task) {
        if (!h.post(task)) {
            return null;
        }

        try {
            return task.get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    private void showToast(final int resid) {
        showToast(getString(resid));
    }

    private void showToast(final String s) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, s, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
